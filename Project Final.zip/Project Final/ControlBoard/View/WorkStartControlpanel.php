<?php 
    include '../Controller/UsernameControllerControlboard.php';
          //$username=$_POST["username"];
		  //echo "<center><h2>Welcome ".getName($username). "</h2></center>";
	            //   $_SESSION['uname'] =$_POST["username"];
		        //  $_SESSION['pass'] = $_POST['password'];


 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title> 
<link rel="stylesheet" href="../../Transport Owner/Style/TrnasportOwnerReg.css">
<style>
		body {
			background-color: lightblue;
		}
        fieldset {
			background-color: black;
		}
	</style>
</head>
<body>
<br />
<div>  
<fieldset style="text-align:center;">               
<div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;">
    <a href="TransportOwner_Registration_Requests.php" style="color: white; text-decoration: none;">TransportOwner Registration Requests</a></br>
</div>
</br>
	</br>
	<div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;">
    <a href="ExporterImporter_Registration_Requests.php" style="color: white; text-decoration: none;">Exporter/Importer Registration Requests</a></br>
</div>
</br>
	</br>
	<div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;">
    <a href="TerminalOwner_Registration_Requests.php" style="color: white; text-decoration: none;">Terminal Owner Registration Requests</a></br>
</div>
</br>
	</br>
<div style="display:inline-block; border: 1px solid magenta; padding: 5px;  margin-right: 10px; background-color: lightskyblue;">
    <a href="ControlBoardLogOut.php" style="color: white; text-decoration: none;">LogOut</a></br>
</div>


</fieldset>

</body>
</html>