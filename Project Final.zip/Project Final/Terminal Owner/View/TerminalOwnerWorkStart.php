<?php 
   
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title> 
<link rel="stylesheet" href="../../Transport Owner/Style/TrnasportOwnerReg.css">
<style>
		body {
			background-color: lightblue;
		}
        fieldset {
			background-color: black;
		}
	</style>
</head>
<body>
<br />
<div>  
<fieldset style="text-align:center;">               
<div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 35px;">
    <a href=".html" style="color: white; text-decoration: none;">Register the Terminal</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href=".html" style="color: white; text-decoration: none;">Edit Profile</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href=".php" style="color: white; text-decoration: none;">View Profile</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 35px;">
    <a href=".php" style="color: white; text-decoration: none;">See Product For Approval Request</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href=".html" style="color: white; text-decoration: none;">See TransPort For Approval Requests</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href=".html" style="color: white; text-decoration: none;">Report Exporter/Importer</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href=".php" style="color: white; text-decoration: none;">Report Transport Owner</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 35px;">
    <a href=".html" style="color: white; text-decoration: none;">Change Password</a></br>
</div>
</br>
	</br>
<div style="display:inline-block; border: 1px solid magenta; padding: 5px;  margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href=".php" style="color: white; text-decoration: none;">LogOut</a></br>
</div>
</fieldset>

</body>
</html>