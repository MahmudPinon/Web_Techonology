<?php 
    include '../Controller/TransportOwnerWorkstartController.php';
         


 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title> 
<link rel="stylesheet" href="../../Transport Owner/Style/TrnasportOwnerReg.css">
<style>
		body {
			background-color: lightblue;
		}
        fieldset {
			background-color: black;
		}
	</style>
</head>
<body>
<br />
<div>  
<fieldset style="text-align:center;">               
<div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 35px;">
    <a href="TransportOwner_RegistrationDriver_and_Helper_and_Vehicle.html" style="color: white; text-decoration: none;">Registered Driver and Helper and Vehicle</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="TransportOwner_EditProfile.html" style="color: white; text-decoration: none;">Edit Profile</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="TransportOwner_View_Profile.php" style="color: white; text-decoration: none;">View Profile</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 35px;">
    <a href="TransportOwner_Change_Driver_Helper_Information.html" style="color: white; text-decoration: none;">Change Driver and Helper Information</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="TransportOwner_UpdateTransportStatus.html" style="color: white; text-decoration: none;">Update Transport Status </a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="TransportOwner_Ask_Demarage.html" style="color: white; text-decoration: none;">Ask Demarage</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="TransportOwner_SeeAvlaibleProduct.php" style="color: white; text-decoration: none;">See Avlaible Product</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 30px;">
    <a href="TransportOwner_Rent_Requests_Response.php" style="color: white; text-decoration: none;">Vehcile Rent Requests Response</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 35px;">
    <a href="TransportOwner_RequesttoBooked_Product.html" style="color: white; text-decoration: none;">Request to the Exporter and Importer for Booked Product</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="TransportOwner_Report_Terminal_Owner.html" style="color: white; text-decoration: none;">Report Terminal</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="TransportOwner_Report_ExporterorImporter.html" style="color: white; text-decoration: none;">Report Exporter/Importer</a></br>
</div>
</br>
	</br>
<div style="display:inline-block; border: 1px solid magenta; padding: 5px;  margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="TransportOwnerLogOut.php" style="color: white; text-decoration: none;">LogOut</a></br>
</div>
</fieldset>

</body>
</html>