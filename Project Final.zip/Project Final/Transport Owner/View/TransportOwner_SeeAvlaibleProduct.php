<?php 
    include '../Controller/TransportOwnerWorkstartController.php';



 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title> 
<link rel="stylesheet" href="../../Transport Owner/Style/TrnasportOwnerReg.css">
<style>
		body {
			background-color: lightblue;
		}
        fieldset {
			background-color: black;
		}
	</style>
</head>
<body>
<br />
<div>  
<fieldset style="text-align:center;">               
<div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 35px;">
    <a href="AvlaibleImportProduct.php" style="color: white; text-decoration: none;">Import Product</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="AvlaibleExportProduct.php" style="color: white; text-decoration: none;">Export Product</a></br>
</div>
</br>
	</br>
    <div style="display:inline-block; border: 1px solid magenta; padding: 5px; margin-right: 10px; background-color: lightskyblue;width: 200px;height: 20px;">
    <a href="TranspoertWonerWorkstart.php" style="color: white; text-decoration: none;">Home</a></br>
</div>
</br>
	</br>
</fieldset>

</body>
</html>