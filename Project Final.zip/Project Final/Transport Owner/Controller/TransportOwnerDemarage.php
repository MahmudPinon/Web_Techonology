<?php
require_once '../Model/Model.php';
echo '<p style="text-align:center; font-weight:bold; color:green; font-size:40px;">Your Request is Under Checking Please Be Patient</p>';
?>
<div style="text-align:center; margin-top: 20px;">
	<button type="button" style="background-color: gray; padding: 10px 20px; font-size: 16px;" onclick="location.href='../View/TranspoertWonerWorkstart.php'">Home</button>
</div>
<?php

?>
