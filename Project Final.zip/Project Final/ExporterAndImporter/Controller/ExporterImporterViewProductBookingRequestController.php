<?php  
require_once '../Model/Model.php';
// $username=$_SESSION['uname'];
function fetchProduct($username)
{
    return provideReqforProduct($username);
}
?>